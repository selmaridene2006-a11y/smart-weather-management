QT += core gui widgets sql printsupport charts multimedia

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

DISTFILES += style.qss

CONFIG += c++17 sdk_no_version_check

TARGET = SmartWeather_Module4
TEMPLATE = app

DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    logindialog.cpp \
    alerte.cpp \
    predictiongel.cpp \
    statsview.cpp \
    connection.cpp

HEADERS += \
    mainwindow.h \
    logindialog.h \
    alerte.h \
    predictiongel.h \
    statsview.h \
    connection.h

FORMS += \
    mainwindow.ui \
    logindialog.ui

RESOURCES += \
    resources.qrc

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
