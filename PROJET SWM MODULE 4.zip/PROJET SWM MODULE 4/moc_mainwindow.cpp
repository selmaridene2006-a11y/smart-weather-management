/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.11.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.11.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace

template <> constexpr inline auto MainWindow::qt_create_metaobjectdata<qt_meta_tag_ZN10MainWindowE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "MainWindow",
        "on_btnNavDashboard_clicked",
        "",
        "on_btnNavAlertes_clicked",
        "on_btnNavStats_clicked",
        "on_btnNavPrediction_clicked",
        "on_stackedWidget_currentChanged",
        "index",
        "on_btnDashNewAlert_clicked",
        "on_btnDashSimulSensor_clicked",
        "on_btnDashTestFrost_clicked",
        "on_btnDashExportPDF_clicked",
        "on_btnSwitchRole_clicked",
        "on_btnAjouter_clicked",
        "on_btnModifier_clicked",
        "on_btnSupprimer_clicked",
        "on_btnArchiver_clicked",
        "on_btnMettreAJourSeverite_clicked",
        "on_btnViderChamps_clicked",
        "on_btnGenererId_clicked",
        "on_btnTriggerAuto_clicked",
        "on_tableAlertes_clicked",
        "QModelIndex",
        "on_tableDashAlertes_clicked",
        "on_txtRecherche_textChanged",
        "arg1",
        "on_cmbFiltreType_currentTextChanged",
        "on_cmbFiltreSeverite_currentTextChanged",
        "on_cmbFiltreStatut_currentTextChanged",
        "on_btnTriSeverite_clicked",
        "on_btnTriDate_clicked",
        "on_btnExportPDF_clicked",
        "on_btnExportTXT_clicked",
        "on_cmbAnneeStats_currentIndexChanged",
        "on_btnRefreshStats_clicked",
        "on_btnCalculerPrediction_clicked",
        "on_btnDeclencherAlerteGel_clicked",
        "on_sliderTemp_valueChanged",
        "value",
        "on_spnTemp_valueChanged",
        "on_sliderHum_valueChanged",
        "on_spnHum_valueChanged",
        "on_sliderVent_valueChanged",
        "on_spnVent_valueChanged",
        "on_sliderNeb_valueChanged",
        "on_spnNeb_valueChanged",
        "on_chkSolHumide_toggled",
        "checked",
        "updateClock",
        "watchdogSensorCheck"
    };

    QtMocHelpers::UintData qt_methods {
        // Slot 'on_btnNavDashboard_clicked'
        QtMocHelpers::SlotData<void()>(1, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnNavAlertes_clicked'
        QtMocHelpers::SlotData<void()>(3, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnNavStats_clicked'
        QtMocHelpers::SlotData<void()>(4, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnNavPrediction_clicked'
        QtMocHelpers::SlotData<void()>(5, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_stackedWidget_currentChanged'
        QtMocHelpers::SlotData<void(int)>(6, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 7 },
        }}),
        // Slot 'on_btnDashNewAlert_clicked'
        QtMocHelpers::SlotData<void()>(8, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnDashSimulSensor_clicked'
        QtMocHelpers::SlotData<void()>(9, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnDashTestFrost_clicked'
        QtMocHelpers::SlotData<void()>(10, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnDashExportPDF_clicked'
        QtMocHelpers::SlotData<void()>(11, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnSwitchRole_clicked'
        QtMocHelpers::SlotData<void()>(12, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnAjouter_clicked'
        QtMocHelpers::SlotData<void()>(13, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnModifier_clicked'
        QtMocHelpers::SlotData<void()>(14, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnSupprimer_clicked'
        QtMocHelpers::SlotData<void()>(15, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnArchiver_clicked'
        QtMocHelpers::SlotData<void()>(16, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnMettreAJourSeverite_clicked'
        QtMocHelpers::SlotData<void()>(17, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnViderChamps_clicked'
        QtMocHelpers::SlotData<void()>(18, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnGenererId_clicked'
        QtMocHelpers::SlotData<void()>(19, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnTriggerAuto_clicked'
        QtMocHelpers::SlotData<void()>(20, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_tableAlertes_clicked'
        QtMocHelpers::SlotData<void(const QModelIndex &)>(21, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 22, 7 },
        }}),
        // Slot 'on_tableDashAlertes_clicked'
        QtMocHelpers::SlotData<void(const QModelIndex &)>(23, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 22, 7 },
        }}),
        // Slot 'on_txtRecherche_textChanged'
        QtMocHelpers::SlotData<void(const QString &)>(24, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 25 },
        }}),
        // Slot 'on_cmbFiltreType_currentTextChanged'
        QtMocHelpers::SlotData<void(const QString &)>(26, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 25 },
        }}),
        // Slot 'on_cmbFiltreSeverite_currentTextChanged'
        QtMocHelpers::SlotData<void(const QString &)>(27, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 25 },
        }}),
        // Slot 'on_cmbFiltreStatut_currentTextChanged'
        QtMocHelpers::SlotData<void(const QString &)>(28, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 25 },
        }}),
        // Slot 'on_btnTriSeverite_clicked'
        QtMocHelpers::SlotData<void()>(29, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnTriDate_clicked'
        QtMocHelpers::SlotData<void()>(30, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnExportPDF_clicked'
        QtMocHelpers::SlotData<void()>(31, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnExportTXT_clicked'
        QtMocHelpers::SlotData<void()>(32, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_cmbAnneeStats_currentIndexChanged'
        QtMocHelpers::SlotData<void(int)>(33, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 7 },
        }}),
        // Slot 'on_btnRefreshStats_clicked'
        QtMocHelpers::SlotData<void()>(34, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnCalculerPrediction_clicked'
        QtMocHelpers::SlotData<void()>(35, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_btnDeclencherAlerteGel_clicked'
        QtMocHelpers::SlotData<void()>(36, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'on_sliderTemp_valueChanged'
        QtMocHelpers::SlotData<void(int)>(37, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 38 },
        }}),
        // Slot 'on_spnTemp_valueChanged'
        QtMocHelpers::SlotData<void(double)>(39, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Double, 25 },
        }}),
        // Slot 'on_sliderHum_valueChanged'
        QtMocHelpers::SlotData<void(int)>(40, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 38 },
        }}),
        // Slot 'on_spnHum_valueChanged'
        QtMocHelpers::SlotData<void(double)>(41, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Double, 25 },
        }}),
        // Slot 'on_sliderVent_valueChanged'
        QtMocHelpers::SlotData<void(int)>(42, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 38 },
        }}),
        // Slot 'on_spnVent_valueChanged'
        QtMocHelpers::SlotData<void(double)>(43, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Double, 25 },
        }}),
        // Slot 'on_sliderNeb_valueChanged'
        QtMocHelpers::SlotData<void(int)>(44, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 38 },
        }}),
        // Slot 'on_spnNeb_valueChanged'
        QtMocHelpers::SlotData<void(int)>(45, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 25 },
        }}),
        // Slot 'on_chkSolHumide_toggled'
        QtMocHelpers::SlotData<void(bool)>(46, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Bool, 47 },
        }}),
        // Slot 'updateClock'
        QtMocHelpers::SlotData<void()>(48, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'watchdogSensorCheck'
        QtMocHelpers::SlotData<void()>(49, 2, QMC::AccessPrivate, QMetaType::Void),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<MainWindow, qt_meta_tag_ZN10MainWindowE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN10MainWindowE_t>.metaTypes,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->on_btnNavDashboard_clicked(); break;
        case 1: _t->on_btnNavAlertes_clicked(); break;
        case 2: _t->on_btnNavStats_clicked(); break;
        case 3: _t->on_btnNavPrediction_clicked(); break;
        case 4: _t->on_stackedWidget_currentChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->on_btnDashNewAlert_clicked(); break;
        case 6: _t->on_btnDashSimulSensor_clicked(); break;
        case 7: _t->on_btnDashTestFrost_clicked(); break;
        case 8: _t->on_btnDashExportPDF_clicked(); break;
        case 9: _t->on_btnSwitchRole_clicked(); break;
        case 10: _t->on_btnAjouter_clicked(); break;
        case 11: _t->on_btnModifier_clicked(); break;
        case 12: _t->on_btnSupprimer_clicked(); break;
        case 13: _t->on_btnArchiver_clicked(); break;
        case 14: _t->on_btnMettreAJourSeverite_clicked(); break;
        case 15: _t->on_btnViderChamps_clicked(); break;
        case 16: _t->on_btnGenererId_clicked(); break;
        case 17: _t->on_btnTriggerAuto_clicked(); break;
        case 18: _t->on_tableAlertes_clicked((*reinterpret_cast<std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 19: _t->on_tableDashAlertes_clicked((*reinterpret_cast<std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 20: _t->on_txtRecherche_textChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 21: _t->on_cmbFiltreType_currentTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 22: _t->on_cmbFiltreSeverite_currentTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 23: _t->on_cmbFiltreStatut_currentTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 24: _t->on_btnTriSeverite_clicked(); break;
        case 25: _t->on_btnTriDate_clicked(); break;
        case 26: _t->on_btnExportPDF_clicked(); break;
        case 27: _t->on_btnExportTXT_clicked(); break;
        case 28: _t->on_cmbAnneeStats_currentIndexChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 29: _t->on_btnRefreshStats_clicked(); break;
        case 30: _t->on_btnCalculerPrediction_clicked(); break;
        case 31: _t->on_btnDeclencherAlerteGel_clicked(); break;
        case 32: _t->on_sliderTemp_valueChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 33: _t->on_spnTemp_valueChanged((*reinterpret_cast<std::add_pointer_t<double>>(_a[1]))); break;
        case 34: _t->on_sliderHum_valueChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 35: _t->on_spnHum_valueChanged((*reinterpret_cast<std::add_pointer_t<double>>(_a[1]))); break;
        case 36: _t->on_sliderVent_valueChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 37: _t->on_spnVent_valueChanged((*reinterpret_cast<std::add_pointer_t<double>>(_a[1]))); break;
        case 38: _t->on_sliderNeb_valueChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 39: _t->on_spnNeb_valueChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 40: _t->on_chkSolHumide_toggled((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1]))); break;
        case 41: _t->updateClock(); break;
        case 42: _t->watchdogSensorCheck(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.strings))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 43;
    }
    return _id;
}
QT_WARNING_POP
