#include "connection.h"
#include <QStandardPaths>
#include <QDir>
#include <QDateTime>

Connection::Connection()
{
}

bool Connection::createconnect()
{
    // Mode SQLite par défaut pour une portabilité totale et une exécution immédiate
    // (Support Oracle possible en remplaçant par QODBC et votre source DSN)
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("smart_weather.db");

    if (!db.open()) {
        qCritical() << "Erreur d'ouverture de la base de données:" << db.lastError().text();
        return false;
    }

    qDebug() << "Connexion à la base de données réussie!";
    initializeTables();
    seedSampleData();
    return true;
}

void Connection::closeConnection()
{
    if (db.isOpen()) {
        db.close();
    }
}

void Connection::initializeTables()
{
    QSqlQuery query;
    QString createTableQuery = 
        "CREATE TABLE IF NOT EXISTS ALERTES ("
        "ID_ALERTE VARCHAR(50) PRIMARY KEY, "
        "TYPE_ALERTE VARCHAR(50) NOT NULL, "
        "NIVEAU_SEVERITE VARCHAR(20) NOT NULL, "
        "DATE_EMISSION TEXT NOT NULL, "
        "DATE_FIN TEXT NOT NULL, "
        "ID_STATION VARCHAR(50) NOT NULL, "
        "GOUVERNORAT VARCHAR(50) NOT NULL, "
        "STATUT VARCHAR(20) DEFAULT 'En cours', "
        "DESCRIPTION TEXT"
        ");";

    if (!query.exec(createTableQuery)) {
        qCritical() << "Erreur création table ALERTES:" << query.lastError().text();
    } else {
        qDebug() << "Table ALERTES vérifiée avec succès.";
    }
}

void Connection::seedSampleData()
{
    QSqlQuery countQuery("SELECT COUNT(*) FROM ALERTES");
    if (countQuery.next() && countQuery.value(0).toInt() == 0) {
        qDebug() << "Insertion des données de démonstration du Module 4...";
        
        struct AlerteInit {
            const char* id;
            const char* type;
            const char* severite;
            const char* dateEmission;
            const char* dateFin;
            const char* station;
            const char* gouv;
            const char* statut;
            const char* desc;
        };

        AlerteInit alertes[] = {
            {"ALT-2026-001", "Gel", "Rouge", "2026-01-14 02:00:00", "2026-01-14 09:30:00", "ST-04_JEN", "Jendouba", "Expirée", "Gel noir critique avec température minimale de -3.5°C au sol."},
            {"ALT-2026-002", "Sirocco/Canicule", "Rouge", "2026-07-21 11:00:00", "2026-07-23 19:00:00", "ST-12_TOZ", "Tozeur", "Expirée", "Vague de chaleur extrême avec vent de Sirocco et températures atteignant 47°C."},
            {"ALT-2026-003", "Vent fort", "Orange", "2026-10-01 08:00:00", "2026-10-03 18:00:00", "ST-01_BIZ", "Bizerte", "En cours", "Rafales de vent du nord-ouest atteignant 95 km/h sur les côtes nord."},
            {"ALT-2026-004", "Tempête", "Orange", "2026-09-18 14:00:00", "2026-09-19 22:00:00", "ST-08_NAB", "Nabeul", "Archivée", "Orages violents accompagnés de grêle et cumuls de pluie dépassant 65mm."},
            {"ALT-2026-005", "Gel", "Orange", "2026-02-05 01:00:00", "2026-02-05 08:30:00", "ST-09_KAS", "Kasserine", "Expirée", "Risque élevé de gel blanc sur les hauts plateaux."},
            {"ALT-2026-006", "Sirocco/Canicule", "Orange", "2026-08-10 10:00:00", "2026-08-11 20:00:00", "ST-07_KAI", "Kairouan", "Archivée", "Températures maximales oscillant entre 43°C et 46°C avec vent de sable sec."},
            {"ALT-2026-007", "Vent fort", "Jaune", "2026-10-02 06:00:00", "2026-10-04 12:00:00", "ST-02_TUN", "Tunis", "En cours", "Vent modéré à fort avec pointes à 65 km/h sur le Grand Tunis."},
            {"ALT-2026-008", "Tempête", "Rouge", "2026-03-25 15:00:00", "2026-03-26 18:00:00", "ST-05_SOU", "Sousse", "Archivée", "Tempête maritime avec vagues de 4 à 5 mètres et vents violents d'est."},
            {"ALT-2026-009", "Gel", "Jaune", "2026-10-02 03:00:00", "2026-10-02 08:00:00", "ST-06_SIL", "Siliana", "En cours", "Gelée matinale modérée en zone de plaine (température proche de +0.5°C)."},
            {"ALT-2026-010", "Sirocco/Canicule", "Jaune", "2026-06-30 12:00:00", "2026-07-01 18:00:00", "ST-11_SFA", "Sfax", "Expirée", "Hausse temporaire des températures avec vent de sud tiède."}
        };

        QSqlQuery insert;
        insert.prepare("INSERT INTO ALERTES (ID_ALERTE, TYPE_ALERTE, NIVEAU_SEVERITE, DATE_EMISSION, DATE_FIN, ID_STATION, GOUVERNORAT, STATUT, DESCRIPTION) "
                       "VALUES (:id, :type, :sev, :demis, :dfin, :st, :gouv, :statut, :desc)");

        for (const auto& a : alertes) {
            insert.bindValue(":id", a.id);
            insert.bindValue(":type", a.type);
            insert.bindValue(":sev", a.severite);
            insert.bindValue(":demis", a.dateEmission);
            insert.bindValue(":dfin", a.dateFin);
            insert.bindValue(":st", a.station);
            insert.bindValue(":gouv", a.gouv);
            insert.bindValue(":statut", a.statut);
            insert.bindValue(":desc", a.desc);
            insert.exec();
        }
        qDebug() << "Données de démonstration insérées avec succès!";
    }
}
