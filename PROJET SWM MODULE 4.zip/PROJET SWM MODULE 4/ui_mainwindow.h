/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *mainHorizontalLayout;
    QFrame *sidebarFrame;
    QVBoxLayout *sidebarVLayout;
    QVBoxLayout *logoLayout;
    QLabel *lblAppTitle;
    QLabel *lblModule;
    QFrame *userCardFrame;
    QVBoxLayout *userCardLayout;
    QLabel *lblUserBadge;
    QLabel *lblRoleBadge;
    QPushButton *btnNavDashboard;
    QPushButton *btnNavAlertes;
    QPushButton *btnNavStats;
    QPushButton *btnNavPrediction;
    QSpacerItem *sidebarSpacer;
    QCheckBox *chkWatchdog;
    QLabel *lblDigitalClock;
    QPushButton *btnSwitchRole;
    QWidget *contentArea;
    QVBoxLayout *contentVLayout;
    QLabel *lblBannerInfo;
    QStackedWidget *stackedWidget;
    QWidget *pageDashboard;
    QVBoxLayout *layoutPageDash;
    QHBoxLayout *kpiDashLayout;
    QFrame *kpiTotal;
    QVBoxLayout *kpiTotalVBox;
    QLabel *lblKpiTotalVal;
    QLabel *lblKpiTotalTitle;
    QFrame *kpiEnCours;
    QVBoxLayout *kpiEnCoursVBox;
    QLabel *lblKpiEnCoursVal;
    QLabel *lblKpiEnCoursTitle;
    QFrame *kpiCritique;
    QVBoxLayout *kpiCritiqueVBox;
    QLabel *lblKpiCritiqueVal;
    QLabel *lblKpiCritiqueTitle;
    QFrame *kpiGel;
    QVBoxLayout *kpiGelVBox;
    QLabel *lblKpiGelVal;
    QLabel *lblKpiGelTitle;
    QFrame *dashActionsFrame;
    QHBoxLayout *dashActionsHLayout;
    QLabel *lblQuickActions;
    QPushButton *btnDashNewAlert;
    QPushButton *btnDashSimulSensor;
    QPushButton *btnDashTestFrost;
    QSpacerItem *dashActSpacer;
    QPushButton *btnDashExportPDF;
    QGroupBox *groupDashRecent;
    QVBoxLayout *dashRecentVLayout;
    QTableView *tableDashAlertes;
    QWidget *pageAlertes;
    QHBoxLayout *layoutPageAlertes;
    QGroupBox *groupFormulaire;
    QVBoxLayout *formVLayout;
    QHBoxLayout *layoutId;
    QLabel *lblId;
    QLineEdit *txtIdAlerte;
    QPushButton *btnGenererId;
    QLabel *lblType;
    QComboBox *cmbTypeAlerte;
    QLabel *lblSeverite;
    QComboBox *cmbSeverite;
    QHBoxLayout *layoutStationGouv;
    QVBoxLayout *vboxStation;
    QLabel *lblStation;
    QLineEdit *txtIdStation;
    QVBoxLayout *vboxGouv;
    QLabel *lblGouv;
    QComboBox *cmbGouvernorat;
    QLabel *lblEmission;
    QDateTimeEdit *dtEmission;
    QLabel *lblFin;
    QDateTimeEdit *dtFin;
    QLabel *lblStatut;
    QComboBox *cmbStatut;
    QLabel *lblDesc;
    QTextEdit *txtDescription;
    QGridLayout *gridCrudButtons;
    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QPushButton *btnSupprimer;
    QPushButton *btnArchiver;
    QPushButton *btnMettreAJourSeverite;
    QPushButton *btnTriggerAuto;
    QPushButton *btnViderChamps;
    QVBoxLayout *rightVLayout;
    QFrame *frameToolbar;
    QHBoxLayout *toolbarLayout;
    QLabel *lblSearchIcon;
    QLineEdit *txtRecherche;
    QLabel *lblFiltreType;
    QComboBox *cmbFiltreType;
    QLabel *lblFiltreSev;
    QComboBox *cmbFiltreSeverite;
    QLabel *lblFiltreStatut;
    QComboBox *cmbFiltreStatut;
    QHBoxLayout *layoutActionsTable;
    QPushButton *btnTriSeverite;
    QPushButton *btnTriDate;
    QSpacerItem *spacerActions;
    QPushButton *btnExportTXT;
    QPushButton *btnExportPDF;
    QTableView *tableAlertes;
    QWidget *pageStats;
    QVBoxLayout *layoutPageStats;
    QFrame *statsControlFrame;
    QHBoxLayout *statsCtrlHBox;
    QLabel *lblAnneeStats;
    QComboBox *cmbAnneeStats;
    QPushButton *btnRefreshStats;
    QSpacerItem *spacerStats;
    QWidget *statsChartContainer;
    QVBoxLayout *layoutCustomStats;
    QWidget *pagePrediction;
    QHBoxLayout *layoutPagePred;
    QGroupBox *groupParamMeteo;
    QVBoxLayout *predParamLayout;
    QLabel *lblStationCible;
    QComboBox *cmbStationCible;
    QHBoxLayout *layoutTempHeader;
    QLabel *lblTemp;
    QDoubleSpinBox *spnTemp;
    QSlider *sliderTemp;
    QHBoxLayout *layoutHumHeader;
    QLabel *lblHum;
    QDoubleSpinBox *spnHum;
    QSlider *sliderHum;
    QHBoxLayout *layoutVentHeader;
    QLabel *lblVent;
    QDoubleSpinBox *spnVent;
    QSlider *sliderVent;
    QHBoxLayout *layoutNebHeader;
    QLabel *lblNeb;
    QSpinBox *spnNeb;
    QSlider *sliderNeb;
    QCheckBox *chkSolHumide;
    QSpacerItem *spacerPred;
    QPushButton *btnCalculerPrediction;
    QGroupBox *groupResultatsPred;
    QVBoxLayout *predResLayout;
    QFrame *frameBadgeRisque;
    QHBoxLayout *badgeLayout;
    QLabel *lblRisqueIcon;
    QVBoxLayout *badgeTextLayout;
    QLabel *lblNiveauRisqueText;
    QLabel *lblProbabiliteText;
    QHBoxLayout *layoutThermique;
    QFrame *boxTMin;
    QVBoxLayout *vboxTMin;
    QLabel *lblTMinTitre;
    QLabel *lblTMinValeur;
    QFrame *boxDew;
    QVBoxLayout *vboxDew;
    QLabel *lblDewTitre;
    QLabel *lblDewValeur;
    QLabel *lblTitreDiag;
    QTextEdit *txtDiagnostic;
    QLabel *lblTitreRecom;
    QTextEdit *txtRecommandations;
    QPushButton *btnDeclencherAlerteGel;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1280, 820);
        MainWindow->setMinimumSize(QSize(1200, 760));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        mainHorizontalLayout = new QHBoxLayout(centralwidget);
        mainHorizontalLayout->setSpacing(0);
        mainHorizontalLayout->setObjectName("mainHorizontalLayout");
        mainHorizontalLayout->setContentsMargins(0, 0, 0, 0);
        sidebarFrame = new QFrame(centralwidget);
        sidebarFrame->setObjectName("sidebarFrame");
        sidebarFrame->setFrameShape(QFrame::NoFrame);
        sidebarVLayout = new QVBoxLayout(sidebarFrame);
        sidebarVLayout->setSpacing(8);
        sidebarVLayout->setObjectName("sidebarVLayout");
        sidebarVLayout->setContentsMargins(14, 20, 14, 16);
        logoLayout = new QVBoxLayout();
        logoLayout->setObjectName("logoLayout");
        lblAppTitle = new QLabel(sidebarFrame);
        lblAppTitle->setObjectName("lblAppTitle");
        lblAppTitle->setStyleSheet(QString::fromUtf8("font-size: 18px; font-weight: 800; color: #0284c7; letter-spacing: 1px;"));

        logoLayout->addWidget(lblAppTitle);

        lblModule = new QLabel(sidebarFrame);
        lblModule->setObjectName("lblModule");
        lblModule->setStyleSheet(QString::fromUtf8("font-size: 11px; color: #64748b; font-weight: 500;"));

        logoLayout->addWidget(lblModule);


        sidebarVLayout->addLayout(logoLayout);

        userCardFrame = new QFrame(sidebarFrame);
        userCardFrame->setObjectName("userCardFrame");
        userCardFrame->setStyleSheet(QString::fromUtf8("background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px; margin-top: 10px; margin-bottom: 10px;"));
        userCardLayout = new QVBoxLayout(userCardFrame);
        userCardLayout->setObjectName("userCardLayout");
        lblUserBadge = new QLabel(userCardFrame);
        lblUserBadge->setObjectName("lblUserBadge");
        lblUserBadge->setStyleSheet(QString::fromUtf8("font-weight: bold; color: #0f172a; font-size: 12px;"));

        userCardLayout->addWidget(lblUserBadge);

        lblRoleBadge = new QLabel(userCardFrame);
        lblRoleBadge->setObjectName("lblRoleBadge");
        lblRoleBadge->setStyleSheet(QString::fromUtf8("color: #0284c7; font-size: 11px; font-weight: 600;"));

        userCardLayout->addWidget(lblRoleBadge);


        sidebarVLayout->addWidget(userCardFrame);

        btnNavDashboard = new QPushButton(sidebarFrame);
        btnNavDashboard->setObjectName("btnNavDashboard");
        btnNavDashboard->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnNavDashboard->setCheckable(true);
        btnNavDashboard->setChecked(true);

        sidebarVLayout->addWidget(btnNavDashboard);

        btnNavAlertes = new QPushButton(sidebarFrame);
        btnNavAlertes->setObjectName("btnNavAlertes");
        btnNavAlertes->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnNavAlertes->setCheckable(true);

        sidebarVLayout->addWidget(btnNavAlertes);

        btnNavStats = new QPushButton(sidebarFrame);
        btnNavStats->setObjectName("btnNavStats");
        btnNavStats->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnNavStats->setCheckable(true);

        sidebarVLayout->addWidget(btnNavStats);

        btnNavPrediction = new QPushButton(sidebarFrame);
        btnNavPrediction->setObjectName("btnNavPrediction");
        btnNavPrediction->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnNavPrediction->setCheckable(true);

        sidebarVLayout->addWidget(btnNavPrediction);

        sidebarSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        sidebarVLayout->addItem(sidebarSpacer);

        chkWatchdog = new QCheckBox(sidebarFrame);
        chkWatchdog->setObjectName("chkWatchdog");
        chkWatchdog->setChecked(true);
        chkWatchdog->setStyleSheet(QString::fromUtf8("color: #64748b; font-size: 11px; font-weight: 500;"));

        sidebarVLayout->addWidget(chkWatchdog);

        lblDigitalClock = new QLabel(sidebarFrame);
        lblDigitalClock->setObjectName("lblDigitalClock");
        lblDigitalClock->setAlignment(Qt::AlignCenter);
        lblDigitalClock->setStyleSheet(QString::fromUtf8("background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px; color: #0369a1; font-family: monospace; font-size: 11px; font-weight: bold;"));

        sidebarVLayout->addWidget(lblDigitalClock);

        btnSwitchRole = new QPushButton(sidebarFrame);
        btnSwitchRole->setObjectName("btnSwitchRole");
        btnSwitchRole->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        sidebarVLayout->addWidget(btnSwitchRole);


        mainHorizontalLayout->addWidget(sidebarFrame);

        contentArea = new QWidget(centralwidget);
        contentArea->setObjectName("contentArea");
        contentVLayout = new QVBoxLayout(contentArea);
        contentVLayout->setSpacing(10);
        contentVLayout->setObjectName("contentVLayout");
        contentVLayout->setContentsMargins(16, 16, 16, 16);
        lblBannerInfo = new QLabel(contentArea);
        lblBannerInfo->setObjectName("lblBannerInfo");
        lblBannerInfo->setStyleSheet(QString::fromUtf8("background-color: #ffffff; color: #0284c7; border: 1px solid #93c5fd; border-radius: 8px; padding: 8px 14px; font-size: 12px; font-weight: bold;"));

        contentVLayout->addWidget(lblBannerInfo);

        stackedWidget = new QStackedWidget(contentArea);
        stackedWidget->setObjectName("stackedWidget");
        pageDashboard = new QWidget();
        pageDashboard->setObjectName("pageDashboard");
        layoutPageDash = new QVBoxLayout(pageDashboard);
        layoutPageDash->setSpacing(14);
        layoutPageDash->setObjectName("layoutPageDash");
        kpiDashLayout = new QHBoxLayout();
        kpiDashLayout->setSpacing(12);
        kpiDashLayout->setObjectName("kpiDashLayout");
        kpiTotal = new QFrame(pageDashboard);
        kpiTotal->setObjectName("kpiTotal");
        kpiTotal->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0284c7, stop:1 #0369a1); color: white; border-radius: 10px; padding: 16px;"));
        kpiTotalVBox = new QVBoxLayout(kpiTotal);
        kpiTotalVBox->setObjectName("kpiTotalVBox");
        lblKpiTotalVal = new QLabel(kpiTotal);
        lblKpiTotalVal->setObjectName("lblKpiTotalVal");
        lblKpiTotalVal->setStyleSheet(QString::fromUtf8("font-size: 28px; font-weight: 800;"));

        kpiTotalVBox->addWidget(lblKpiTotalVal);

        lblKpiTotalTitle = new QLabel(kpiTotal);
        lblKpiTotalTitle->setObjectName("lblKpiTotalTitle");
        lblKpiTotalTitle->setStyleSheet(QString::fromUtf8("font-size: 12px; opacity: 0.9;"));

        kpiTotalVBox->addWidget(lblKpiTotalTitle);


        kpiDashLayout->addWidget(kpiTotal);

        kpiEnCours = new QFrame(pageDashboard);
        kpiEnCours->setObjectName("kpiEnCours");
        kpiEnCours->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #10b981, stop:1 #059669); color: white; border-radius: 10px; padding: 16px;"));
        kpiEnCoursVBox = new QVBoxLayout(kpiEnCours);
        kpiEnCoursVBox->setObjectName("kpiEnCoursVBox");
        lblKpiEnCoursVal = new QLabel(kpiEnCours);
        lblKpiEnCoursVal->setObjectName("lblKpiEnCoursVal");
        lblKpiEnCoursVal->setStyleSheet(QString::fromUtf8("font-size: 28px; font-weight: 800;"));

        kpiEnCoursVBox->addWidget(lblKpiEnCoursVal);

        lblKpiEnCoursTitle = new QLabel(kpiEnCours);
        lblKpiEnCoursTitle->setObjectName("lblKpiEnCoursTitle");
        lblKpiEnCoursTitle->setStyleSheet(QString::fromUtf8("font-size: 12px; opacity: 0.9;"));

        kpiEnCoursVBox->addWidget(lblKpiEnCoursTitle);


        kpiDashLayout->addWidget(kpiEnCours);

        kpiCritique = new QFrame(pageDashboard);
        kpiCritique->setObjectName("kpiCritique");
        kpiCritique->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ef4444, stop:1 #dc2626); color: white; border-radius: 10px; padding: 16px;"));
        kpiCritiqueVBox = new QVBoxLayout(kpiCritique);
        kpiCritiqueVBox->setObjectName("kpiCritiqueVBox");
        lblKpiCritiqueVal = new QLabel(kpiCritique);
        lblKpiCritiqueVal->setObjectName("lblKpiCritiqueVal");
        lblKpiCritiqueVal->setStyleSheet(QString::fromUtf8("font-size: 28px; font-weight: 800;"));

        kpiCritiqueVBox->addWidget(lblKpiCritiqueVal);

        lblKpiCritiqueTitle = new QLabel(kpiCritique);
        lblKpiCritiqueTitle->setObjectName("lblKpiCritiqueTitle");
        lblKpiCritiqueTitle->setStyleSheet(QString::fromUtf8("font-size: 12px; opacity: 0.9;"));

        kpiCritiqueVBox->addWidget(lblKpiCritiqueTitle);


        kpiDashLayout->addWidget(kpiCritique);

        kpiGel = new QFrame(pageDashboard);
        kpiGel->setObjectName("kpiGel");
        kpiGel->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8b5cf6, stop:1 #7c3aed); color: white; border-radius: 10px; padding: 16px;"));
        kpiGelVBox = new QVBoxLayout(kpiGel);
        kpiGelVBox->setObjectName("kpiGelVBox");
        lblKpiGelVal = new QLabel(kpiGel);
        lblKpiGelVal->setObjectName("lblKpiGelVal");
        lblKpiGelVal->setStyleSheet(QString::fromUtf8("font-size: 28px; font-weight: 800;"));

        kpiGelVBox->addWidget(lblKpiGelVal);

        lblKpiGelTitle = new QLabel(kpiGel);
        lblKpiGelTitle->setObjectName("lblKpiGelTitle");
        lblKpiGelTitle->setStyleSheet(QString::fromUtf8("font-size: 12px; opacity: 0.9;"));

        kpiGelVBox->addWidget(lblKpiGelTitle);


        kpiDashLayout->addWidget(kpiGel);


        layoutPageDash->addLayout(kpiDashLayout);

        dashActionsFrame = new QFrame(pageDashboard);
        dashActionsFrame->setObjectName("dashActionsFrame");
        dashActionsFrame->setStyleSheet(QString::fromUtf8("background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px;"));
        dashActionsHLayout = new QHBoxLayout(dashActionsFrame);
        dashActionsHLayout->setObjectName("dashActionsHLayout");
        lblQuickActions = new QLabel(dashActionsFrame);
        lblQuickActions->setObjectName("lblQuickActions");
        lblQuickActions->setStyleSheet(QString::fromUtf8("font-weight: bold; color: #0f172a; font-size: 13px;"));

        dashActionsHLayout->addWidget(lblQuickActions);

        btnDashNewAlert = new QPushButton(dashActionsFrame);
        btnDashNewAlert->setObjectName("btnDashNewAlert");
        btnDashNewAlert->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        dashActionsHLayout->addWidget(btnDashNewAlert);

        btnDashSimulSensor = new QPushButton(dashActionsFrame);
        btnDashSimulSensor->setObjectName("btnDashSimulSensor");
        btnDashSimulSensor->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnDashSimulSensor->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #7c3aed, stop:1 #6d28d9);"));

        dashActionsHLayout->addWidget(btnDashSimulSensor);

        btnDashTestFrost = new QPushButton(dashActionsFrame);
        btnDashTestFrost->setObjectName("btnDashTestFrost");
        btnDashTestFrost->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnDashTestFrost->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0f766e, stop:1 #115e59);"));

        dashActionsHLayout->addWidget(btnDashTestFrost);

        dashActSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        dashActionsHLayout->addItem(dashActSpacer);

        btnDashExportPDF = new QPushButton(dashActionsFrame);
        btnDashExportPDF->setObjectName("btnDashExportPDF");
        btnDashExportPDF->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnDashExportPDF->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #be123c, stop:1 #9f1239);"));

        dashActionsHLayout->addWidget(btnDashExportPDF);


        layoutPageDash->addWidget(dashActionsFrame);

        groupDashRecent = new QGroupBox(pageDashboard);
        groupDashRecent->setObjectName("groupDashRecent");
        dashRecentVLayout = new QVBoxLayout(groupDashRecent);
        dashRecentVLayout->setObjectName("dashRecentVLayout");
        tableDashAlertes = new QTableView(groupDashRecent);
        tableDashAlertes->setObjectName("tableDashAlertes");
        tableDashAlertes->setSelectionMode(QAbstractItemView::SingleSelection);
        tableDashAlertes->setSelectionBehavior(QAbstractItemView::SelectRows);

        dashRecentVLayout->addWidget(tableDashAlertes);


        layoutPageDash->addWidget(groupDashRecent);

        stackedWidget->addWidget(pageDashboard);
        pageAlertes = new QWidget();
        pageAlertes->setObjectName("pageAlertes");
        layoutPageAlertes = new QHBoxLayout(pageAlertes);
        layoutPageAlertes->setSpacing(12);
        layoutPageAlertes->setObjectName("layoutPageAlertes");
        groupFormulaire = new QGroupBox(pageAlertes);
        groupFormulaire->setObjectName("groupFormulaire");
        groupFormulaire->setMinimumSize(QSize(380, 0));
        groupFormulaire->setMaximumSize(QSize(420, 16777215));
        formVLayout = new QVBoxLayout(groupFormulaire);
        formVLayout->setSpacing(7);
        formVLayout->setObjectName("formVLayout");
        layoutId = new QHBoxLayout();
        layoutId->setObjectName("layoutId");
        lblId = new QLabel(groupFormulaire);
        lblId->setObjectName("lblId");

        layoutId->addWidget(lblId);

        txtIdAlerte = new QLineEdit(groupFormulaire);
        txtIdAlerte->setObjectName("txtIdAlerte");

        layoutId->addWidget(txtIdAlerte);

        btnGenererId = new QPushButton(groupFormulaire);
        btnGenererId->setObjectName("btnGenererId");
        btnGenererId->setStyleSheet(QString::fromUtf8("background: #64748b; color: white; padding: 5px 8px; font-size: 11px; border-radius: 4px;"));

        layoutId->addWidget(btnGenererId);


        formVLayout->addLayout(layoutId);

        lblType = new QLabel(groupFormulaire);
        lblType->setObjectName("lblType");

        formVLayout->addWidget(lblType);

        cmbTypeAlerte = new QComboBox(groupFormulaire);
        cmbTypeAlerte->addItem(QString());
        cmbTypeAlerte->addItem(QString());
        cmbTypeAlerte->addItem(QString());
        cmbTypeAlerte->addItem(QString());
        cmbTypeAlerte->setObjectName("cmbTypeAlerte");

        formVLayout->addWidget(cmbTypeAlerte);

        lblSeverite = new QLabel(groupFormulaire);
        lblSeverite->setObjectName("lblSeverite");

        formVLayout->addWidget(lblSeverite);

        cmbSeverite = new QComboBox(groupFormulaire);
        cmbSeverite->addItem(QString());
        cmbSeverite->addItem(QString());
        cmbSeverite->addItem(QString());
        cmbSeverite->setObjectName("cmbSeverite");

        formVLayout->addWidget(cmbSeverite);

        layoutStationGouv = new QHBoxLayout();
        layoutStationGouv->setObjectName("layoutStationGouv");
        vboxStation = new QVBoxLayout();
        vboxStation->setObjectName("vboxStation");
        lblStation = new QLabel(groupFormulaire);
        lblStation->setObjectName("lblStation");

        vboxStation->addWidget(lblStation);

        txtIdStation = new QLineEdit(groupFormulaire);
        txtIdStation->setObjectName("txtIdStation");

        vboxStation->addWidget(txtIdStation);


        layoutStationGouv->addLayout(vboxStation);

        vboxGouv = new QVBoxLayout();
        vboxGouv->setObjectName("vboxGouv");
        lblGouv = new QLabel(groupFormulaire);
        lblGouv->setObjectName("lblGouv");

        vboxGouv->addWidget(lblGouv);

        cmbGouvernorat = new QComboBox(groupFormulaire);
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->addItem(QString());
        cmbGouvernorat->setObjectName("cmbGouvernorat");

        vboxGouv->addWidget(cmbGouvernorat);


        layoutStationGouv->addLayout(vboxGouv);


        formVLayout->addLayout(layoutStationGouv);

        lblEmission = new QLabel(groupFormulaire);
        lblEmission->setObjectName("lblEmission");

        formVLayout->addWidget(lblEmission);

        dtEmission = new QDateTimeEdit(groupFormulaire);
        dtEmission->setObjectName("dtEmission");
        dtEmission->setCalendarPopup(true);

        formVLayout->addWidget(dtEmission);

        lblFin = new QLabel(groupFormulaire);
        lblFin->setObjectName("lblFin");

        formVLayout->addWidget(lblFin);

        dtFin = new QDateTimeEdit(groupFormulaire);
        dtFin->setObjectName("dtFin");
        dtFin->setCalendarPopup(true);

        formVLayout->addWidget(dtFin);

        lblStatut = new QLabel(groupFormulaire);
        lblStatut->setObjectName("lblStatut");

        formVLayout->addWidget(lblStatut);

        cmbStatut = new QComboBox(groupFormulaire);
        cmbStatut->addItem(QString());
        cmbStatut->addItem(QString());
        cmbStatut->addItem(QString());
        cmbStatut->setObjectName("cmbStatut");

        formVLayout->addWidget(cmbStatut);

        lblDesc = new QLabel(groupFormulaire);
        lblDesc->setObjectName("lblDesc");

        formVLayout->addWidget(lblDesc);

        txtDescription = new QTextEdit(groupFormulaire);
        txtDescription->setObjectName("txtDescription");
        txtDescription->setMaximumSize(QSize(16777215, 60));

        formVLayout->addWidget(txtDescription);

        gridCrudButtons = new QGridLayout();
        gridCrudButtons->setObjectName("gridCrudButtons");
        btnAjouter = new QPushButton(groupFormulaire);
        btnAjouter->setObjectName("btnAjouter");
        btnAjouter->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnAjouter->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #22c55e, stop:1 #16a34a);"));

        gridCrudButtons->addWidget(btnAjouter, 0, 0, 1, 1);

        btnModifier = new QPushButton(groupFormulaire);
        btnModifier->setObjectName("btnModifier");
        btnModifier->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        gridCrudButtons->addWidget(btnModifier, 0, 1, 1, 1);

        btnSupprimer = new QPushButton(groupFormulaire);
        btnSupprimer->setObjectName("btnSupprimer");
        btnSupprimer->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnSupprimer->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ef4444, stop:1 #dc2626);"));

        gridCrudButtons->addWidget(btnSupprimer, 1, 0, 1, 1);

        btnArchiver = new QPushButton(groupFormulaire);
        btnArchiver->setObjectName("btnArchiver");
        btnArchiver->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnArchiver->setStyleSheet(QString::fromUtf8("background: #64748b; color: white;"));

        gridCrudButtons->addWidget(btnArchiver, 1, 1, 1, 1);


        formVLayout->addLayout(gridCrudButtons);

        btnMettreAJourSeverite = new QPushButton(groupFormulaire);
        btnMettreAJourSeverite->setObjectName("btnMettreAJourSeverite");
        btnMettreAJourSeverite->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnMettreAJourSeverite->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #f97316, stop:1 #ea580c);"));

        formVLayout->addWidget(btnMettreAJourSeverite);

        btnTriggerAuto = new QPushButton(groupFormulaire);
        btnTriggerAuto->setObjectName("btnTriggerAuto");
        btnTriggerAuto->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnTriggerAuto->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #7c3aed, stop:1 #6d28d9);"));

        formVLayout->addWidget(btnTriggerAuto);

        btnViderChamps = new QPushButton(groupFormulaire);
        btnViderChamps->setObjectName("btnViderChamps");
        btnViderChamps->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnViderChamps->setStyleSheet(QString::fromUtf8("background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1;"));

        formVLayout->addWidget(btnViderChamps);


        layoutPageAlertes->addWidget(groupFormulaire);

        rightVLayout = new QVBoxLayout();
        rightVLayout->setSpacing(10);
        rightVLayout->setObjectName("rightVLayout");
        frameToolbar = new QFrame(pageAlertes);
        frameToolbar->setObjectName("frameToolbar");
        frameToolbar->setStyleSheet(QString::fromUtf8("background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 6px;"));
        toolbarLayout = new QHBoxLayout(frameToolbar);
        toolbarLayout->setObjectName("toolbarLayout");
        lblSearchIcon = new QLabel(frameToolbar);
        lblSearchIcon->setObjectName("lblSearchIcon");

        toolbarLayout->addWidget(lblSearchIcon);

        txtRecherche = new QLineEdit(frameToolbar);
        txtRecherche->setObjectName("txtRecherche");

        toolbarLayout->addWidget(txtRecherche);

        lblFiltreType = new QLabel(frameToolbar);
        lblFiltreType->setObjectName("lblFiltreType");

        toolbarLayout->addWidget(lblFiltreType);

        cmbFiltreType = new QComboBox(frameToolbar);
        cmbFiltreType->addItem(QString());
        cmbFiltreType->addItem(QString());
        cmbFiltreType->addItem(QString());
        cmbFiltreType->addItem(QString());
        cmbFiltreType->addItem(QString());
        cmbFiltreType->setObjectName("cmbFiltreType");

        toolbarLayout->addWidget(cmbFiltreType);

        lblFiltreSev = new QLabel(frameToolbar);
        lblFiltreSev->setObjectName("lblFiltreSev");

        toolbarLayout->addWidget(lblFiltreSev);

        cmbFiltreSeverite = new QComboBox(frameToolbar);
        cmbFiltreSeverite->addItem(QString());
        cmbFiltreSeverite->addItem(QString());
        cmbFiltreSeverite->addItem(QString());
        cmbFiltreSeverite->addItem(QString());
        cmbFiltreSeverite->setObjectName("cmbFiltreSeverite");

        toolbarLayout->addWidget(cmbFiltreSeverite);

        lblFiltreStatut = new QLabel(frameToolbar);
        lblFiltreStatut->setObjectName("lblFiltreStatut");

        toolbarLayout->addWidget(lblFiltreStatut);

        cmbFiltreStatut = new QComboBox(frameToolbar);
        cmbFiltreStatut->addItem(QString());
        cmbFiltreStatut->addItem(QString());
        cmbFiltreStatut->addItem(QString());
        cmbFiltreStatut->addItem(QString());
        cmbFiltreStatut->setObjectName("cmbFiltreStatut");

        toolbarLayout->addWidget(cmbFiltreStatut);


        rightVLayout->addWidget(frameToolbar);

        layoutActionsTable = new QHBoxLayout();
        layoutActionsTable->setObjectName("layoutActionsTable");
        btnTriSeverite = new QPushButton(pageAlertes);
        btnTriSeverite->setObjectName("btnTriSeverite");
        btnTriSeverite->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnTriSeverite->setStyleSheet(QString::fromUtf8("background: #0284c7;"));

        layoutActionsTable->addWidget(btnTriSeverite);

        btnTriDate = new QPushButton(pageAlertes);
        btnTriDate->setObjectName("btnTriDate");
        btnTriDate->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnTriDate->setStyleSheet(QString::fromUtf8("background: #0369a1;"));

        layoutActionsTable->addWidget(btnTriDate);

        spacerActions = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        layoutActionsTable->addItem(spacerActions);

        btnExportTXT = new QPushButton(pageAlertes);
        btnExportTXT->setObjectName("btnExportTXT");
        btnExportTXT->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnExportTXT->setStyleSheet(QString::fromUtf8("background: #0f766e;"));

        layoutActionsTable->addWidget(btnExportTXT);

        btnExportPDF = new QPushButton(pageAlertes);
        btnExportPDF->setObjectName("btnExportPDF");
        btnExportPDF->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnExportPDF->setStyleSheet(QString::fromUtf8("background: #be123c;"));

        layoutActionsTable->addWidget(btnExportPDF);


        rightVLayout->addLayout(layoutActionsTable);

        tableAlertes = new QTableView(pageAlertes);
        tableAlertes->setObjectName("tableAlertes");
        tableAlertes->setSelectionMode(QAbstractItemView::SingleSelection);
        tableAlertes->setSelectionBehavior(QAbstractItemView::SelectRows);

        rightVLayout->addWidget(tableAlertes);


        layoutPageAlertes->addLayout(rightVLayout);

        stackedWidget->addWidget(pageAlertes);
        pageStats = new QWidget();
        pageStats->setObjectName("pageStats");
        layoutPageStats = new QVBoxLayout(pageStats);
        layoutPageStats->setSpacing(12);
        layoutPageStats->setObjectName("layoutPageStats");
        statsControlFrame = new QFrame(pageStats);
        statsControlFrame->setObjectName("statsControlFrame");
        statsControlFrame->setStyleSheet(QString::fromUtf8("background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;"));
        statsCtrlHBox = new QHBoxLayout(statsControlFrame);
        statsCtrlHBox->setObjectName("statsCtrlHBox");
        lblAnneeStats = new QLabel(statsControlFrame);
        lblAnneeStats->setObjectName("lblAnneeStats");
        lblAnneeStats->setStyleSheet(QString::fromUtf8("font-weight: bold; color: #0f172a;"));

        statsCtrlHBox->addWidget(lblAnneeStats);

        cmbAnneeStats = new QComboBox(statsControlFrame);
        cmbAnneeStats->addItem(QString());
        cmbAnneeStats->addItem(QString());
        cmbAnneeStats->addItem(QString());
        cmbAnneeStats->setObjectName("cmbAnneeStats");
        cmbAnneeStats->setMinimumSize(QSize(120, 0));

        statsCtrlHBox->addWidget(cmbAnneeStats);

        btnRefreshStats = new QPushButton(statsControlFrame);
        btnRefreshStats->setObjectName("btnRefreshStats");
        btnRefreshStats->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        statsCtrlHBox->addWidget(btnRefreshStats);

        spacerStats = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        statsCtrlHBox->addItem(spacerStats);


        layoutPageStats->addWidget(statsControlFrame);

        statsChartContainer = new QWidget(pageStats);
        statsChartContainer->setObjectName("statsChartContainer");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(statsChartContainer->sizePolicy().hasHeightForWidth());
        statsChartContainer->setSizePolicy(sizePolicy);
        layoutCustomStats = new QVBoxLayout(statsChartContainer);
        layoutCustomStats->setObjectName("layoutCustomStats");
        layoutCustomStats->setContentsMargins(0, 0, 0, 0);

        layoutPageStats->addWidget(statsChartContainer);

        stackedWidget->addWidget(pageStats);
        pagePrediction = new QWidget();
        pagePrediction->setObjectName("pagePrediction");
        layoutPagePred = new QHBoxLayout(pagePrediction);
        layoutPagePred->setSpacing(14);
        layoutPagePred->setObjectName("layoutPagePred");
        groupParamMeteo = new QGroupBox(pagePrediction);
        groupParamMeteo->setObjectName("groupParamMeteo");
        groupParamMeteo->setMinimumSize(QSize(440, 0));
        groupParamMeteo->setMaximumSize(QSize(480, 16777215));
        predParamLayout = new QVBoxLayout(groupParamMeteo);
        predParamLayout->setSpacing(10);
        predParamLayout->setObjectName("predParamLayout");
        lblStationCible = new QLabel(groupParamMeteo);
        lblStationCible->setObjectName("lblStationCible");

        predParamLayout->addWidget(lblStationCible);

        cmbStationCible = new QComboBox(groupParamMeteo);
        cmbStationCible->addItem(QString());
        cmbStationCible->addItem(QString());
        cmbStationCible->addItem(QString());
        cmbStationCible->addItem(QString());
        cmbStationCible->addItem(QString());
        cmbStationCible->setObjectName("cmbStationCible");

        predParamLayout->addWidget(cmbStationCible);

        layoutTempHeader = new QHBoxLayout();
        layoutTempHeader->setObjectName("layoutTempHeader");
        lblTemp = new QLabel(groupParamMeteo);
        lblTemp->setObjectName("lblTemp");

        layoutTempHeader->addWidget(lblTemp);

        spnTemp = new QDoubleSpinBox(groupParamMeteo);
        spnTemp->setObjectName("spnTemp");
        spnTemp->setMinimum(-10.000000000000000);
        spnTemp->setMaximum(35.000000000000000);
        spnTemp->setValue(4.500000000000000);
        spnTemp->setSingleStep(0.500000000000000);

        layoutTempHeader->addWidget(spnTemp);


        predParamLayout->addLayout(layoutTempHeader);

        sliderTemp = new QSlider(groupParamMeteo);
        sliderTemp->setObjectName("sliderTemp");
        sliderTemp->setOrientation(Qt::Horizontal);
        sliderTemp->setMinimum(-100);
        sliderTemp->setMaximum(350);
        sliderTemp->setValue(45);

        predParamLayout->addWidget(sliderTemp);

        layoutHumHeader = new QHBoxLayout();
        layoutHumHeader->setObjectName("layoutHumHeader");
        lblHum = new QLabel(groupParamMeteo);
        lblHum->setObjectName("lblHum");

        layoutHumHeader->addWidget(lblHum);

        spnHum = new QDoubleSpinBox(groupParamMeteo);
        spnHum->setObjectName("spnHum");
        spnHum->setMinimum(10.000000000000000);
        spnHum->setMaximum(100.000000000000000);
        spnHum->setValue(68.000000000000000);
        spnHum->setSingleStep(1.000000000000000);

        layoutHumHeader->addWidget(spnHum);


        predParamLayout->addLayout(layoutHumHeader);

        sliderHum = new QSlider(groupParamMeteo);
        sliderHum->setObjectName("sliderHum");
        sliderHum->setOrientation(Qt::Horizontal);
        sliderHum->setMinimum(10);
        sliderHum->setMaximum(100);
        sliderHum->setValue(68);

        predParamLayout->addWidget(sliderHum);

        layoutVentHeader = new QHBoxLayout();
        layoutVentHeader->setObjectName("layoutVentHeader");
        lblVent = new QLabel(groupParamMeteo);
        lblVent->setObjectName("lblVent");

        layoutVentHeader->addWidget(lblVent);

        spnVent = new QDoubleSpinBox(groupParamMeteo);
        spnVent->setObjectName("spnVent");
        spnVent->setMinimum(0.000000000000000);
        spnVent->setMaximum(100.000000000000000);
        spnVent->setValue(3.500000000000000);
        spnVent->setSingleStep(0.500000000000000);

        layoutVentHeader->addWidget(spnVent);


        predParamLayout->addLayout(layoutVentHeader);

        sliderVent = new QSlider(groupParamMeteo);
        sliderVent->setObjectName("sliderVent");
        sliderVent->setOrientation(Qt::Horizontal);
        sliderVent->setMinimum(0);
        sliderVent->setMaximum(1000);
        sliderVent->setValue(35);

        predParamLayout->addWidget(sliderVent);

        layoutNebHeader = new QHBoxLayout();
        layoutNebHeader->setObjectName("layoutNebHeader");
        lblNeb = new QLabel(groupParamMeteo);
        lblNeb->setObjectName("lblNeb");

        layoutNebHeader->addWidget(lblNeb);

        spnNeb = new QSpinBox(groupParamMeteo);
        spnNeb->setObjectName("spnNeb");
        spnNeb->setMinimum(0);
        spnNeb->setMaximum(8);
        spnNeb->setValue(0);

        layoutNebHeader->addWidget(spnNeb);


        predParamLayout->addLayout(layoutNebHeader);

        sliderNeb = new QSlider(groupParamMeteo);
        sliderNeb->setObjectName("sliderNeb");
        sliderNeb->setOrientation(Qt::Horizontal);
        sliderNeb->setMinimum(0);
        sliderNeb->setMaximum(8);
        sliderNeb->setValue(0);

        predParamLayout->addWidget(sliderNeb);

        chkSolHumide = new QCheckBox(groupParamMeteo);
        chkSolHumide->setObjectName("chkSolHumide");

        predParamLayout->addWidget(chkSolHumide);

        spacerPred = new QSpacerItem(20, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        predParamLayout->addItem(spacerPred);

        btnCalculerPrediction = new QPushButton(groupParamMeteo);
        btnCalculerPrediction->setObjectName("btnCalculerPrediction");
        btnCalculerPrediction->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnCalculerPrediction->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0284c7, stop:1 #0369a1); padding: 12px; font-size: 13px;"));

        predParamLayout->addWidget(btnCalculerPrediction);


        layoutPagePred->addWidget(groupParamMeteo);

        groupResultatsPred = new QGroupBox(pagePrediction);
        groupResultatsPred->setObjectName("groupResultatsPred");
        predResLayout = new QVBoxLayout(groupResultatsPred);
        predResLayout->setSpacing(12);
        predResLayout->setObjectName("predResLayout");
        frameBadgeRisque = new QFrame(groupResultatsPred);
        frameBadgeRisque->setObjectName("frameBadgeRisque");
        frameBadgeRisque->setStyleSheet(QString::fromUtf8("background-color: #fef2f2; border: 2px solid #ef4444; border-radius: 8px; padding: 12px;"));
        badgeLayout = new QHBoxLayout(frameBadgeRisque);
        badgeLayout->setObjectName("badgeLayout");
        lblRisqueIcon = new QLabel(frameBadgeRisque);
        lblRisqueIcon->setObjectName("lblRisqueIcon");
        lblRisqueIcon->setStyleSheet(QString::fromUtf8("font-size: 32px;"));

        badgeLayout->addWidget(lblRisqueIcon);

        badgeTextLayout = new QVBoxLayout();
        badgeTextLayout->setObjectName("badgeTextLayout");
        lblNiveauRisqueText = new QLabel(frameBadgeRisque);
        lblNiveauRisqueText->setObjectName("lblNiveauRisqueText");
        lblNiveauRisqueText->setStyleSheet(QString::fromUtf8("font-size: 16px; font-weight: bold; color: #b91c1c;"));

        badgeTextLayout->addWidget(lblNiveauRisqueText);

        lblProbabiliteText = new QLabel(frameBadgeRisque);
        lblProbabiliteText->setObjectName("lblProbabiliteText");
        lblProbabiliteText->setStyleSheet(QString::fromUtf8("font-size: 12px; color: #7f1d1d;"));

        badgeTextLayout->addWidget(lblProbabiliteText);


        badgeLayout->addLayout(badgeTextLayout);


        predResLayout->addWidget(frameBadgeRisque);

        layoutThermique = new QHBoxLayout();
        layoutThermique->setObjectName("layoutThermique");
        boxTMin = new QFrame(groupResultatsPred);
        boxTMin->setObjectName("boxTMin");
        boxTMin->setStyleSheet(QString::fromUtf8("background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;"));
        vboxTMin = new QVBoxLayout(boxTMin);
        vboxTMin->setObjectName("vboxTMin");
        lblTMinTitre = new QLabel(boxTMin);
        lblTMinTitre->setObjectName("lblTMinTitre");
        lblTMinTitre->setStyleSheet(QString::fromUtf8("color: #64748b; font-size: 11px; font-weight: 500;"));

        vboxTMin->addWidget(lblTMinTitre);

        lblTMinValeur = new QLabel(boxTMin);
        lblTMinValeur->setObjectName("lblTMinValeur");
        lblTMinValeur->setStyleSheet(QString::fromUtf8("font-size: 22px; font-weight: bold; color: #0284c7;"));

        vboxTMin->addWidget(lblTMinValeur);


        layoutThermique->addWidget(boxTMin);

        boxDew = new QFrame(groupResultatsPred);
        boxDew->setObjectName("boxDew");
        boxDew->setStyleSheet(QString::fromUtf8("background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;"));
        vboxDew = new QVBoxLayout(boxDew);
        vboxDew->setObjectName("vboxDew");
        lblDewTitre = new QLabel(boxDew);
        lblDewTitre->setObjectName("lblDewTitre");
        lblDewTitre->setStyleSheet(QString::fromUtf8("color: #64748b; font-size: 11px; font-weight: 500;"));

        vboxDew->addWidget(lblDewTitre);

        lblDewValeur = new QLabel(boxDew);
        lblDewValeur->setObjectName("lblDewValeur");
        lblDewValeur->setStyleSheet(QString::fromUtf8("font-size: 22px; font-weight: bold; color: #0d9488;"));

        vboxDew->addWidget(lblDewValeur);


        layoutThermique->addWidget(boxDew);


        predResLayout->addLayout(layoutThermique);

        lblTitreDiag = new QLabel(groupResultatsPred);
        lblTitreDiag->setObjectName("lblTitreDiag");
        lblTitreDiag->setStyleSheet(QString::fromUtf8("font-weight: bold; color: #0f172a;"));

        predResLayout->addWidget(lblTitreDiag);

        txtDiagnostic = new QTextEdit(groupResultatsPred);
        txtDiagnostic->setObjectName("txtDiagnostic");
        txtDiagnostic->setReadOnly(true);
        txtDiagnostic->setMaximumSize(QSize(16777215, 85));

        predResLayout->addWidget(txtDiagnostic);

        lblTitreRecom = new QLabel(groupResultatsPred);
        lblTitreRecom->setObjectName("lblTitreRecom");
        lblTitreRecom->setStyleSheet(QString::fromUtf8("font-weight: bold; color: #0f172a;"));

        predResLayout->addWidget(lblTitreRecom);

        txtRecommandations = new QTextEdit(groupResultatsPred);
        txtRecommandations->setObjectName("txtRecommandations");
        txtRecommandations->setReadOnly(true);

        predResLayout->addWidget(txtRecommandations);

        btnDeclencherAlerteGel = new QPushButton(groupResultatsPred);
        btnDeclencherAlerteGel->setObjectName("btnDeclencherAlerteGel");
        btnDeclencherAlerteGel->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnDeclencherAlerteGel->setStyleSheet(QString::fromUtf8("background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ef4444, stop:1 #dc2626); color: white; padding: 12px; font-size: 13px; font-weight: bold;"));

        predResLayout->addWidget(btnDeclencherAlerteGel);


        layoutPagePred->addWidget(groupResultatsPred);

        stackedWidget->addWidget(pagePrediction);

        contentVLayout->addWidget(stackedWidget);


        mainHorizontalLayout->addWidget(contentArea);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Smart Weather Management - Module 4 : Gestion des Alertes & Pr\303\251dictions", nullptr));
        lblAppTitle->setText(QCoreApplication::translate("MainWindow", "\342\232\241 SMART WEATHER", nullptr));
        lblModule->setText(QCoreApplication::translate("MainWindow", "Module 4 : Alertes & Pr\303\251dictions", nullptr));
        lblUserBadge->setText(QCoreApplication::translate("MainWindow", "\360\237\221\244 vigilance_admin", nullptr));
        lblRoleBadge->setText(QCoreApplication::translate("MainWindow", "Responsable de la vigilance", nullptr));
        btnNavDashboard->setText(QCoreApplication::translate("MainWindow", "\360\237\217\240  Supervision Globale", nullptr));
        btnNavAlertes->setText(QCoreApplication::translate("MainWindow", "\360\237\223\213  Journal des Alertes", nullptr));
        btnNavStats->setText(QCoreApplication::translate("MainWindow", "\360\237\223\212  Analyses R\303\251gionales", nullptr));
        btnNavPrediction->setText(QCoreApplication::translate("MainWindow", "\342\235\204\357\270\217  Pr\303\251diction Risque Gel", nullptr));
        chkWatchdog->setText(QCoreApplication::translate("MainWindow", "\360\237\223\241 Veille Capteurs Auto", nullptr));
        lblDigitalClock->setText(QCoreApplication::translate("MainWindow", "2026-10-02 12:00:00", nullptr));
        btnSwitchRole->setText(QCoreApplication::translate("MainWindow", "\360\237\224\204 Changer de R\303\264le", nullptr));
        lblBannerInfo->setText(QCoreApplication::translate("MainWindow", "\360\237\237\242 Surveillance active : 3 alertes en cours sur le territoire national.", nullptr));
        lblKpiTotalVal->setText(QCoreApplication::translate("MainWindow", "10", nullptr));
        lblKpiTotalTitle->setText(QCoreApplication::translate("MainWindow", "Total des Alertes", nullptr));
        lblKpiEnCoursVal->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lblKpiEnCoursTitle->setText(QCoreApplication::translate("MainWindow", "Alertes en cours (Vigilance active)", nullptr));
        lblKpiCritiqueVal->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lblKpiCritiqueTitle->setText(QCoreApplication::translate("MainWindow", "S\303\251v\303\251rit\303\251 ROUGE (Urgence absolue)", nullptr));
        lblKpiGelVal->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lblKpiGelTitle->setText(QCoreApplication::translate("MainWindow", "Risques de Gel D\303\251tect\303\251s", nullptr));
        lblQuickActions->setText(QCoreApplication::translate("MainWindow", "\342\232\241 Actions Rapides :", nullptr));
        btnDashNewAlert->setText(QCoreApplication::translate("MainWindow", "\342\236\225 D\303\251clencher Nouvelle Alerte", nullptr));
        btnDashSimulSensor->setText(QCoreApplication::translate("MainWindow", "\360\237\223\241 Simuler D\303\251passement Seuil Capteur", nullptr));
        btnDashTestFrost->setText(QCoreApplication::translate("MainWindow", "\342\235\204\357\270\217 \303\211valuer Risque Gel Nocturne", nullptr));
        btnDashExportPDF->setText(QCoreApplication::translate("MainWindow", "\360\237\223\204 Exporter Journal PDF", nullptr));
        groupDashRecent->setTitle(QCoreApplication::translate("MainWindow", "Registre des Derni\303\250res Alertes M\303\251t\303\251orologiques \303\211mises", nullptr));
        groupFormulaire->setTitle(QCoreApplication::translate("MainWindow", "Formulaire de D\303\251clenchement & Saisie", nullptr));
        lblId->setText(QCoreApplication::translate("MainWindow", "ID Alerte :", nullptr));
        txtIdAlerte->setPlaceholderText(QCoreApplication::translate("MainWindow", "ex: ALT-2026-011", nullptr));
        btnGenererId->setText(QCoreApplication::translate("MainWindow", "G\303\251n\303\251rer", nullptr));
        lblType->setText(QCoreApplication::translate("MainWindow", "Type d'Alerte :", nullptr));
        cmbTypeAlerte->setItemText(0, QCoreApplication::translate("MainWindow", "Gel", nullptr));
        cmbTypeAlerte->setItemText(1, QCoreApplication::translate("MainWindow", "Sirocco/Canicule", nullptr));
        cmbTypeAlerte->setItemText(2, QCoreApplication::translate("MainWindow", "Temp\303\252te", nullptr));
        cmbTypeAlerte->setItemText(3, QCoreApplication::translate("MainWindow", "Vent fort", nullptr));

        lblSeverite->setText(QCoreApplication::translate("MainWindow", "Niveau de S\303\251v\303\251rit\303\251 :", nullptr));
        cmbSeverite->setItemText(0, QCoreApplication::translate("MainWindow", "Jaune", nullptr));
        cmbSeverite->setItemText(1, QCoreApplication::translate("MainWindow", "Orange", nullptr));
        cmbSeverite->setItemText(2, QCoreApplication::translate("MainWindow", "Rouge", nullptr));

        lblStation->setText(QCoreApplication::translate("MainWindow", "ID Station :", nullptr));
        txtIdStation->setPlaceholderText(QCoreApplication::translate("MainWindow", "ex: ST-04_JEN", nullptr));
        lblGouv->setText(QCoreApplication::translate("MainWindow", "Gouvernorat :", nullptr));
        cmbGouvernorat->setItemText(0, QCoreApplication::translate("MainWindow", "Tunis", nullptr));
        cmbGouvernorat->setItemText(1, QCoreApplication::translate("MainWindow", "Ariana", nullptr));
        cmbGouvernorat->setItemText(2, QCoreApplication::translate("MainWindow", "Ben Arous", nullptr));
        cmbGouvernorat->setItemText(3, QCoreApplication::translate("MainWindow", "Manouba", nullptr));
        cmbGouvernorat->setItemText(4, QCoreApplication::translate("MainWindow", "Nabeul", nullptr));
        cmbGouvernorat->setItemText(5, QCoreApplication::translate("MainWindow", "Zaghouan", nullptr));
        cmbGouvernorat->setItemText(6, QCoreApplication::translate("MainWindow", "Bizerte", nullptr));
        cmbGouvernorat->setItemText(7, QCoreApplication::translate("MainWindow", "B\303\251ja", nullptr));
        cmbGouvernorat->setItemText(8, QCoreApplication::translate("MainWindow", "Jendouba", nullptr));
        cmbGouvernorat->setItemText(9, QCoreApplication::translate("MainWindow", "Le Kef", nullptr));
        cmbGouvernorat->setItemText(10, QCoreApplication::translate("MainWindow", "Siliana", nullptr));
        cmbGouvernorat->setItemText(11, QCoreApplication::translate("MainWindow", "Kairouan", nullptr));
        cmbGouvernorat->setItemText(12, QCoreApplication::translate("MainWindow", "Kasserine", nullptr));
        cmbGouvernorat->setItemText(13, QCoreApplication::translate("MainWindow", "Sidi Bouzid", nullptr));
        cmbGouvernorat->setItemText(14, QCoreApplication::translate("MainWindow", "Sousse", nullptr));
        cmbGouvernorat->setItemText(15, QCoreApplication::translate("MainWindow", "Monastir", nullptr));
        cmbGouvernorat->setItemText(16, QCoreApplication::translate("MainWindow", "Mahdia", nullptr));
        cmbGouvernorat->setItemText(17, QCoreApplication::translate("MainWindow", "Sfax", nullptr));
        cmbGouvernorat->setItemText(18, QCoreApplication::translate("MainWindow", "Gafsa", nullptr));
        cmbGouvernorat->setItemText(19, QCoreApplication::translate("MainWindow", "Tozeur", nullptr));
        cmbGouvernorat->setItemText(20, QCoreApplication::translate("MainWindow", "K\303\251bili", nullptr));
        cmbGouvernorat->setItemText(21, QCoreApplication::translate("MainWindow", "Gab\303\250s", nullptr));
        cmbGouvernorat->setItemText(22, QCoreApplication::translate("MainWindow", "M\303\251denine", nullptr));
        cmbGouvernorat->setItemText(23, QCoreApplication::translate("MainWindow", "Tataouine", nullptr));

        lblEmission->setText(QCoreApplication::translate("MainWindow", "Date & Heure d'\303\211mission :", nullptr));
        dtEmission->setDisplayFormat(QCoreApplication::translate("MainWindow", "yyyy-MM-dd HH:mm:ss", nullptr));
        lblFin->setText(QCoreApplication::translate("MainWindow", "Date & Heure de Fin :", nullptr));
        dtFin->setDisplayFormat(QCoreApplication::translate("MainWindow", "yyyy-MM-dd HH:mm:ss", nullptr));
        lblStatut->setText(QCoreApplication::translate("MainWindow", "Statut :", nullptr));
        cmbStatut->setItemText(0, QCoreApplication::translate("MainWindow", "En cours", nullptr));
        cmbStatut->setItemText(1, QCoreApplication::translate("MainWindow", "Expir\303\251e", nullptr));
        cmbStatut->setItemText(2, QCoreApplication::translate("MainWindow", "Archiv\303\251e", nullptr));

        lblDesc->setText(QCoreApplication::translate("MainWindow", "Description / Consignes op\303\251rationnelles :", nullptr));
        txtDescription->setPlaceholderText(QCoreApplication::translate("MainWindow", "Pr\303\251ciser la port\303\251e, les risques encourus et les mesures de pr\303\251caution...", nullptr));
        btnAjouter->setText(QCoreApplication::translate("MainWindow", "\342\236\225 Cr\303\251er Alerte", nullptr));
        btnModifier->setText(QCoreApplication::translate("MainWindow", "\342\234\217\357\270\217 Modifier", nullptr));
        btnSupprimer->setText(QCoreApplication::translate("MainWindow", "\360\237\227\221\357\270\217 Supprimer", nullptr));
        btnArchiver->setText(QCoreApplication::translate("MainWindow", "\360\237\223\246 Archiver", nullptr));
        btnMettreAJourSeverite->setText(QCoreApplication::translate("MainWindow", "\360\237\224\272 Escalade S\303\251v\303\251rit\303\251 (Jaune \342\236\224 Orange \342\236\224 Rouge)", nullptr));
        btnTriggerAuto->setText(QCoreApplication::translate("MainWindow", "\342\232\241 D\303\251clencher Automatiquement (Capteur)", nullptr));
        btnViderChamps->setText(QCoreApplication::translate("MainWindow", "\360\237\224\204 R\303\251initialiser le Formulaire", nullptr));
        lblSearchIcon->setText(QCoreApplication::translate("MainWindow", "\360\237\224\215", nullptr));
        txtRecherche->setPlaceholderText(QCoreApplication::translate("MainWindow", "Recherche par ID, gouvernorat, station, mot-cl\303\251...", nullptr));
        lblFiltreType->setText(QCoreApplication::translate("MainWindow", "Type :", nullptr));
        cmbFiltreType->setItemText(0, QCoreApplication::translate("MainWindow", "Tous", nullptr));
        cmbFiltreType->setItemText(1, QCoreApplication::translate("MainWindow", "Gel", nullptr));
        cmbFiltreType->setItemText(2, QCoreApplication::translate("MainWindow", "Sirocco/Canicule", nullptr));
        cmbFiltreType->setItemText(3, QCoreApplication::translate("MainWindow", "Temp\303\252te", nullptr));
        cmbFiltreType->setItemText(4, QCoreApplication::translate("MainWindow", "Vent fort", nullptr));

        lblFiltreSev->setText(QCoreApplication::translate("MainWindow", "S\303\251v\303\251rit\303\251 :", nullptr));
        cmbFiltreSeverite->setItemText(0, QCoreApplication::translate("MainWindow", "Tous", nullptr));
        cmbFiltreSeverite->setItemText(1, QCoreApplication::translate("MainWindow", "Rouge", nullptr));
        cmbFiltreSeverite->setItemText(2, QCoreApplication::translate("MainWindow", "Orange", nullptr));
        cmbFiltreSeverite->setItemText(3, QCoreApplication::translate("MainWindow", "Jaune", nullptr));

        lblFiltreStatut->setText(QCoreApplication::translate("MainWindow", "Statut :", nullptr));
        cmbFiltreStatut->setItemText(0, QCoreApplication::translate("MainWindow", "Tous", nullptr));
        cmbFiltreStatut->setItemText(1, QCoreApplication::translate("MainWindow", "En cours", nullptr));
        cmbFiltreStatut->setItemText(2, QCoreApplication::translate("MainWindow", "Expir\303\251e", nullptr));
        cmbFiltreStatut->setItemText(3, QCoreApplication::translate("MainWindow", "Archiv\303\251e", nullptr));

        btnTriSeverite->setText(QCoreApplication::translate("MainWindow", "\360\237\232\250 Trier par S\303\251v\303\251rit\303\251 (Rouge \342\236\224 Jaune)", nullptr));
        btnTriDate->setText(QCoreApplication::translate("MainWindow", "\360\237\223\205 Trier par Date (Plus R\303\251cente)", nullptr));
        btnExportTXT->setText(QCoreApplication::translate("MainWindow", "\360\237\223\235 Exporter TXT", nullptr));
        btnExportPDF->setText(QCoreApplication::translate("MainWindow", "\360\237\223\204 Exporter PDF R\303\251glementaire", nullptr));
        lblAnneeStats->setText(QCoreApplication::translate("MainWindow", "S\303\251lectionner l'Ann\303\251e d'analyse :", nullptr));
        cmbAnneeStats->setItemText(0, QCoreApplication::translate("MainWindow", "2026", nullptr));
        cmbAnneeStats->setItemText(1, QCoreApplication::translate("MainWindow", "2025", nullptr));
        cmbAnneeStats->setItemText(2, QCoreApplication::translate("MainWindow", "2024", nullptr));

        btnRefreshStats->setText(QCoreApplication::translate("MainWindow", "\360\237\224\204 Actualiser le Graphique", nullptr));
        groupParamMeteo->setTitle(QCoreApplication::translate("MainWindow", "Param\303\250tres M\303\251t\303\251orologiques d'Entr\303\251e & Sliders", nullptr));
        lblStationCible->setText(QCoreApplication::translate("MainWindow", "Station / R\303\251gion Agricole surveill\303\251e :", nullptr));
        cmbStationCible->setItemText(0, QCoreApplication::translate("MainWindow", "ST-04_JEN (Jendouba - Vall\303\251e de la Medjerda)", nullptr));
        cmbStationCible->setItemText(1, QCoreApplication::translate("MainWindow", "ST-06_SIL (Siliana - Hautes Plaines)", nullptr));
        cmbStationCible->setItemText(2, QCoreApplication::translate("MainWindow", "ST-09_KAS (Kasserine - Zone Montagneuse)", nullptr));
        cmbStationCible->setItemText(3, QCoreApplication::translate("MainWindow", "ST-07_KAI (Kairouan - Oliveraies)", nullptr));
        cmbStationCible->setItemText(4, QCoreApplication::translate("MainWindow", "ST-08_NAB (Nabeul - Agrumes Cap Bon)", nullptr));

        lblTemp->setText(QCoreApplication::translate("MainWindow", "T\302\260 au cr\303\251puscule (\302\260C) :", nullptr));
        lblHum->setText(QCoreApplication::translate("MainWindow", "Humidit\303\251 relative de l'air (%) :", nullptr));
        lblVent->setText(QCoreApplication::translate("MainWindow", "Vitesse moyenne du vent (km/h) :", nullptr));
        lblNeb->setText(QCoreApplication::translate("MainWindow", "N\303\251bulosit\303\251 du ciel (0 Clair \342\236\224 8 Couvert) :", nullptr));
        chkSolHumide->setText(QCoreApplication::translate("MainWindow", "Sol r\303\251cemment irrigu\303\251 / humide", nullptr));
        btnCalculerPrediction->setText(QCoreApplication::translate("MainWindow", "\360\237\224\256 Lancer la Pr\303\251diction Algorithmique", nullptr));
        groupResultatsPred->setTitle(QCoreApplication::translate("MainWindow", "Diagnostic Agrom\303\251t\303\251orologique & D\303\251cision Op\303\251rationnelle", nullptr));
        lblRisqueIcon->setText(QCoreApplication::translate("MainWindow", "\360\237\232\250", nullptr));
        lblNiveauRisqueText->setText(QCoreApplication::translate("MainWindow", "RISQUE \303\211LEV\303\211 DE GEL BLANC (Niveau Orange)", nullptr));
        lblProbabiliteText->setText(QCoreApplication::translate("MainWindow", "Probabilit\303\251 estim\303\251e : 80% | Type : Gel radiatif nocturne", nullptr));
        lblTMinTitre->setText(QCoreApplication::translate("MainWindow", "T\302\260 Min. Nocturne Pr\303\251vue", nullptr));
        lblTMinValeur->setText(QCoreApplication::translate("MainWindow", "-1.2 \302\260C", nullptr));
        lblDewTitre->setText(QCoreApplication::translate("MainWindow", "Point de Ros\303\251e Calcul\303\251", nullptr));
        lblDewValeur->setText(QCoreApplication::translate("MainWindow", "-0.8 \302\260C", nullptr));
        lblTitreDiag->setText(QCoreApplication::translate("MainWindow", "Analyse Physique & Diagnostic :", nullptr));
        lblTitreRecom->setText(QCoreApplication::translate("MainWindow", "Mesures Pr\303\251ventives & Protection Agricole Imm\303\251diate :", nullptr));
        btnDeclencherAlerteGel->setText(QCoreApplication::translate("MainWindow", "\360\237\232\250 D\303\251clencher Automatiquement l'Alerte Gel pour cette Station", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
