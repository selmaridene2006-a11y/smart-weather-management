/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 6.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_LoginDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *lblHeaderTitle;
    QLabel *lblHeaderSub;
    QFrame *lineSep;
    QLabel *lblRoleSection;
    QPushButton *btnRoleVigilance;
    QPushButton *btnRoleProtection;
    QPushButton *btnRoleDecideur;
    QLabel *lblUser;
    QLineEdit *txtUsername;
    QLabel *lblPass;
    QLineEdit *txtPassword;
    QPushButton *btnLogin;

    void setupUi(QDialog *LoginDialog)
    {
        if (LoginDialog->objectName().isEmpty())
            LoginDialog->setObjectName("LoginDialog");
        LoginDialog->resize(540, 520);
        LoginDialog->setStyleSheet(QString::fromUtf8("\n"
"    QDialog {\n"
"        background-color: #ffffff;\n"
"        color: #0f172a;\n"
"        font-family: \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif;\n"
"    }\n"
"    QLabel {\n"
"        color: #334155;\n"
"    }\n"
"    QLineEdit {\n"
"        background-color: #ffffff;\n"
"        border: 1.5px solid #cbd5e1;\n"
"        border-radius: 8px;\n"
"        padding: 10px;\n"
"        color: #0f172a;\n"
"        font-size: 13px;\n"
"    }\n"
"    QLineEdit:focus {\n"
"        border: 1.5px solid #0284c7;\n"
"    }\n"
"    QPushButton {\n"
"        border-radius: 8px;\n"
"        padding: 10px 16px;\n"
"        font-size: 13px;\n"
"        font-weight: bold;\n"
"    }\n"
"    QPushButton#btnLogin {\n"
"        background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0284c7, stop:1 #0369a1);\n"
"        color: #ffffff;\n"
"        border: none;\n"
"    }\n"
"    QPushButton#btnLogin:hover {\n"
"        background: #0369a1;\n"
"    }\n"
"   "));
        verticalLayout = new QVBoxLayout(LoginDialog);
        verticalLayout->setSpacing(16);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(30, 25, 30, 25);
        lblHeaderTitle = new QLabel(LoginDialog);
        lblHeaderTitle->setObjectName("lblHeaderTitle");
        lblHeaderTitle->setAlignment(Qt::AlignCenter);
        lblHeaderTitle->setStyleSheet(QString::fromUtf8("font-size: 20px; font-weight: bold; color: #0284c7; letter-spacing: 1px;"));

        verticalLayout->addWidget(lblHeaderTitle);

        lblHeaderSub = new QLabel(LoginDialog);
        lblHeaderSub->setObjectName("lblHeaderSub");
        lblHeaderSub->setAlignment(Qt::AlignCenter);
        lblHeaderSub->setStyleSheet(QString::fromUtf8("font-size: 13px; color: #64748b;"));

        verticalLayout->addWidget(lblHeaderSub);

        lineSep = new QFrame(LoginDialog);
        lineSep->setObjectName("lineSep");
        lineSep->setFrameShape(QFrame::HLine);
        lineSep->setFrameShadow(QFrame::Sunken);
        lineSep->setStyleSheet(QString::fromUtf8("color: #e2e8f0;"));

        verticalLayout->addWidget(lineSep);

        lblRoleSection = new QLabel(LoginDialog);
        lblRoleSection->setObjectName("lblRoleSection");
        lblRoleSection->setStyleSheet(QString::fromUtf8("font-weight: bold; font-size: 13px; color: #0f172a;"));

        verticalLayout->addWidget(lblRoleSection);

        btnRoleVigilance = new QPushButton(LoginDialog);
        btnRoleVigilance->setObjectName("btnRoleVigilance");
        btnRoleVigilance->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnRoleVigilance->setStyleSheet(QString::fromUtf8("\n"
"        background-color: #f0f9ff;\n"
"        color: #0284c7;\n"
"        border: 2px solid #0284c7;\n"
"        text-align: left;\n"
"        padding: 12px;\n"
"      "));

        verticalLayout->addWidget(btnRoleVigilance);

        btnRoleProtection = new QPushButton(LoginDialog);
        btnRoleProtection->setObjectName("btnRoleProtection");
        btnRoleProtection->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnRoleProtection->setStyleSheet(QString::fromUtf8("\n"
"        background-color: #ffffff;\n"
"        color: #ea580c;\n"
"        border: 1px solid #fed7aa;\n"
"        text-align: left;\n"
"        padding: 12px;\n"
"      "));

        verticalLayout->addWidget(btnRoleProtection);

        btnRoleDecideur = new QPushButton(LoginDialog);
        btnRoleDecideur->setObjectName("btnRoleDecideur");
        btnRoleDecideur->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        btnRoleDecideur->setStyleSheet(QString::fromUtf8("\n"
"        background-color: #ffffff;\n"
"        color: #9333ea;\n"
"        border: 1px solid #e9d5ff;\n"
"        text-align: left;\n"
"        padding: 12px;\n"
"      "));

        verticalLayout->addWidget(btnRoleDecideur);

        lblUser = new QLabel(LoginDialog);
        lblUser->setObjectName("lblUser");
        lblUser->setStyleSheet(QString::fromUtf8("font-size: 12px; color: #475569; margin-top: 8px;"));

        verticalLayout->addWidget(lblUser);

        txtUsername = new QLineEdit(LoginDialog);
        txtUsername->setObjectName("txtUsername");

        verticalLayout->addWidget(txtUsername);

        lblPass = new QLabel(LoginDialog);
        lblPass->setObjectName("lblPass");
        lblPass->setStyleSheet(QString::fromUtf8("font-size: 12px; color: #475569;"));

        verticalLayout->addWidget(lblPass);

        txtPassword = new QLineEdit(LoginDialog);
        txtPassword->setObjectName("txtPassword");
        txtPassword->setEchoMode(QLineEdit::Password);

        verticalLayout->addWidget(txtPassword);

        btnLogin = new QPushButton(LoginDialog);
        btnLogin->setObjectName("btnLogin");
        btnLogin->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));

        verticalLayout->addWidget(btnLogin);


        retranslateUi(LoginDialog);

        QMetaObject::connectSlotsByName(LoginDialog);
    } // setupUi

    void retranslateUi(QDialog *LoginDialog)
    {
        LoginDialog->setWindowTitle(QCoreApplication::translate("LoginDialog", "SWM - Connexion & Choix du R\303\264le", nullptr));
        lblHeaderTitle->setText(QCoreApplication::translate("LoginDialog", "SMART WEATHER MANAGEMENT", nullptr));
        lblHeaderSub->setText(QCoreApplication::translate("LoginDialog", "Module 4 : Gestion des Alertes & Pr\303\251dictions", nullptr));
        lblRoleSection->setText(QCoreApplication::translate("LoginDialog", "S\303\251lectionnez un r\303\264le pour tester :", nullptr));
        btnRoleVigilance->setText(QCoreApplication::translate("LoginDialog", "\360\237\221\244 Responsable de la vigilance (Tous droits)", nullptr));
        btnRoleProtection->setText(QCoreApplication::translate("LoginDialog", "\360\237\233\241\357\270\217 Protection civile (Consultation uniquement)", nullptr));
        btnRoleDecideur->setText(QCoreApplication::translate("LoginDialog", "\360\237\217\233\357\270\217 D\303\251cideur institutionnel (Analyses & Rapports)", nullptr));
        lblUser->setText(QCoreApplication::translate("LoginDialog", "Nom d'utilisateur / Matricule :", nullptr));
        txtUsername->setPlaceholderText(QCoreApplication::translate("LoginDialog", "Identifiant agent", nullptr));
        lblPass->setText(QCoreApplication::translate("LoginDialog", "Mot de passe :", nullptr));
        txtPassword->setPlaceholderText(QCoreApplication::translate("LoginDialog", "Mot de passe", nullptr));
        btnLogin->setText(QCoreApplication::translate("LoginDialog", "Acc\303\251der au Module \342\236\224", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginDialog: public Ui_LoginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
