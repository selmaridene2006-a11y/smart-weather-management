#include "mainwindow.h"
#include "logindialog.h"
#include "connection.h"
#include <QApplication>
#include <QMessageBox>
#include <QFile>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Initialisation et vérification de la connexion à la base de données
    Connection c;
    bool dbOk = c.createconnect();

    if (!dbOk) {
        QMessageBox::critical(nullptr, "Erreur Base de Données",
                              "Impossible de se connecter à la base de données Smart Weather.\n"
                              "Vérifiez l'intégrité du fichier de base de données local.");
        return 1;
    }

    // Affichage de la boîte de dialogue de sélection du rôle
    LoginDialog login;
    if (login.exec() == QDialog::Accepted) {
        MainWindow w;
        w.setUtilisateur(login.getUsername(), login.getSelectedRole());
        w.show();
        return a.exec();
    }

    return 0;
}
