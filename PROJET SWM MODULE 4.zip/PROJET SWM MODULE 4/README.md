# SMART WEATHER MANAGEMENT — MODULE 4 : GESTION DES ALERTES & PRÉDICTIONS
### Projet C++ / Qt Creator — Conformité Spécifications & Guide d'Excellence ESPRIT

---

## 🌟 Améliorations Intégrées Basées sur le Guide ESPRIT

| N° | Sujet du Guide | Référence & Lien | Implémentation dans le Projet |
| :--- | :--- | :--- | :--- |
| **1** | **Personnalisation GUI via Qt Stylesheets** | `qt-stylesheets-tutorial` | Fichier [style.qss](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/style.qss) épuré (**Thème Daylight Clear / Clarté Diurne**) : fond blanc et ardoise claire, lisibilité maximale, dégradés azur vifs, cartes blanches et contrastes nets adaptés aux présentations universitaires. |
| **2** | **Insérer des images & Ressources** | `QTDesignerLesformulaires.html` | Intégration via [resources.qrc](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/resources.qrc), icônes vectorielles et badges de sévérité. |
| **3** | **Ajouter du son** | Audio alert / son d'avertissement | Avertisseur sonore automatique (`QApplication::beep()`) lors du franchissement de seuil critique ou alerte rouge. |
| **4** | **Création du binaire / Déploiement** | Options `.pro` | Configuration complète dans [SmartWeather_Module4.pro](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/SmartWeather_Module4.pro). |
| **5** | **Dimensionnement de la fenêtre** | `Empecherleredimensionnement.html` | Contraintes de taille minimale (`setMinimumSize(1240, 780)`) garantissant un affichage réactif optimal. |
| **6** | **Créer un Timer (`QTimer`)** | `ProgrammeruntempsTimer.html` | • **Horloge digitale temps réel** actualisée chaque seconde (`updateClock`).<br>• **Timer de veille capteurs** (`watchdogSensorCheck`) inspectant en continu les seuils météo. |
| **7** | **Échanges de données entre fenêtres** | `Creerunraccourcisdanslemenu.html` | Synchronisation des sessions, matricules et permissions entre [logindialog.cpp](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/logindialog.cpp) et [mainwindow.cpp](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/mainwindow.cpp). |
| **8** | **Recherche SQL & Sécurité** | `bindValue` / `QSqlQuery` | Toutes les requêtes SQL (CRUD, recherche, tri) utilisent `prepare()` et `bindValue()`. |
| **9** | **Génération de Statistiques** | `Charts` / Visualisation | Composant personnalisé [statsview.cpp](file:///Users/faroukpersonals/Downloads/PROJET%20SWM%20MODULE%204/statsview.cpp) (histogramme des alertes par gouvernorat + donut de sévérité). |
| **10** | **Minimiser les interfaces : Sidebar & QStackedWidget** | `UsingQStackedWidget.htm`, `qt-sidebar-tutorial` | Barre latérale de navigation verticale avec boutons d'onglets commutant un `QStackedWidget` à 4 pages. |
| **11** | **Personnalisation des boutons** | `Custom Button Stylesheet` | Boutons avec dégradés thématiques (`btnSuccess`, `btnDanger`, `btnWarning`, `btnSecondary`) et états au survol/clic. |
| **12** | **Animations graphiques** | `framework-animation` | Animation fluide de fondu (`QPropertyAnimation` + `QGraphicsOpacityEffect`) sur la bannière de notification d'alerte. |
| **23** | **Fancy Sliders Stylesheet** | `fancy-qslider-stylesheet` | 4 sliders interactifs synchronisés en direct avec les spinbox pour la **Prédiction du Risque de Gel Nocturne** (T°, Humidité, Vent, Nébulosité). |

---

## 🏛️ Navigation de l'Interface (4 Pages `QStackedWidget`)

1. **🏠 Supervision Globale** :
   - Cartes KPI dynamiques (Total, En cours, Rouge critique, Risques de gel).
   - Accès rapide aux actions clés (Nouvelle alerte, Simulation capteur, Évaluation gel, Export PDF).
   - Flux opérationnel des dernières alertes enregistrées.
2. **📋 Journal des Alertes (CRUD)** :
   - Formulaire de création / modification avec contrôles de validité.
   - Bouton de mise à jour rapide de sévérité (`Jaune ➔ Orange ➔ Rouge`).
   - Recherche textuelle instantanée multi-champs.
   - Filtres croisés par type, sévérité et statut.
   - Tri par sévérité prioritaire ou par date.
   - Exportations officielles en PDF réglementaire et TXT.
3. **📊 Analyses Régionales & Statistiques** :
   - Graphique comparatif par gouvernorat sur l'année sélectionnée.
   - Diagramme donut de répartition des niveaux de vigilance.
4. **❄️ Innovation : Prédiction du Risque de Gel Nocturne** :
   - Paramètres météo avec curseurs sliders interactifs en temps réel.
   - Estimation de la baisse nocturne, température minimale et point de rosée (Magnus-Tetens).
   - Diagnostic agrométéorologique et consignes de protection des cultures.
   - Déclenchement automatique de l'alerte Gel en base pour la station surveillée.

---

## 🚀 Lancement Rapide sous Qt Creator

1. Ouvrez **Qt Creator**.
2. Ouvrez le fichier :
   ```
   /Users/faroukpersonals/Downloads/PROJET SWM MODULE 4/SmartWeather_Module4.pro
   ```
3. Cliquez sur le bouton vert **Run** (`Cmd + R` ou `Ctrl + R`).
